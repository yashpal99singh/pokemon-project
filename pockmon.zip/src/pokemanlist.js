import React, { useState, useEffect } from 'react';
import axios from 'axios';

const PokemonList = () => {
  const [pokemonData, setPokemonData] = useState([]);
  const [filteredPokemonData, setFilteredPokemonData] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [pokemonPerPage] = useState(10);

  useEffect(() => {
    const fetchPokemonData = async () => {
      const response = await axios.get('https://pokeapi.co/api/v2/pokemon?limit=150');
      setPokemonData(response.data.results);
    };

    fetchPokemonData();
  }, []);

  useEffect(() => {
    const filteredData = pokemonData.filter(pokemon =>
      pokemon.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredPokemonData(filteredData);
    setCurrentPage(1);
  }, [pokemonData, searchTerm]);

  const handleSearchChange = e => {
    setSearchTerm(e.target.value);
  };

  const handlePageChange = pageNumber => {
    setCurrentPage(pageNumber);
  };

  const indexOfLastPokemon = currentPage * pokemonPerPage;
  const indexOfFirstPokemon = indexOfLastPokemon - pokemonPerPage;
  const currentPokemon = filteredPokemonData.slice(indexOfFirstPokemon, indexOfLastPokemon);

  return (
    <div>
      <h1>Pokémon List - Paginated</h1>
      <input type="text" placeholder="Search Pokémon" value={searchTerm} onChange={handleSearchChange} />
      <ul>
        {currentPokemon.map(pokemon => (
          <li key={pokemon.name}>{pokemon.name}</li>
        ))}
      </ul>
      <div>
        {filteredPokemonData.length > pokemonPerPage && (
          <ul className="pagination">
            {Array(Math.ceil(filteredPokemonData.length / pokemonPerPage))
              .fill()
              .map((_, index) => (
                <li key={index + 1} className={currentPage === index + 1 ? 'active' : ''}>
                  <button onClick={() => handlePageChange(index + 1)}>{index + 1}</button>
                </li>
              ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default PokemonList;

