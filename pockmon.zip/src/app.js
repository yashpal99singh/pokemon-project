import React from 'react';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';
import PokemonList from './pokemanlist';
import LazyLoadPokemonList from './lazyloadingpokemanlist';

function App() {
  return (
    <Router>
      <div>
        <nav>
          <ul>
            <li>
              <Link to="/">Paginated List</Link>
            </li>
            <li>
              <Link to="/lazy-load">Lazy Load</Link>
            </li>
          </ul>
        </nav>

        <Switch>
          <Route path="/" exact component={PokemonList} />
          <Route path="/lazy-load" component={LazyLoadPokemonList} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;
