import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';

const LazyLoadPokemonList = () => {
  const [pokemonData, setPokemonData] = useState([]);
  const [filteredPokemonData, setFilteredPokemonData] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [pokemonPerPage] = useState(10);
  const [isFetching, setIsFetching] = useState(false);
  const observer = useRef();

  useEffect(() => {
    const fetchPokemonData = async () => {
      const response = await axios.get(`https://pokeapi.co/api/v2/pokemon?limit=${currentPage * pokemonPerPage}`);
      setPokemonData(response.data.results);
    };

    fetchPokemonData();
  }, [currentPage]);

  useEffect(() => {
    const filteredData = pokemonData.filter(pokemon =>
      pokemon.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredPokemonData(filteredData);
    setCurrentPage(1);
  }, [pokemonData, searchTerm]);

  useEffect(() => {
    const options = {
      root: null,
      rootMargin: '0px',
      threshold: 0.5,
    };

    const handleObserver = entries => {
      const target = entries[0];
      if (target.isIntersecting) {
        setIsFetching(true);
        setCurrentPage(prevPage => prevPage + 1);
      }
    };

    observer.current = new IntersectionObserver(handleObserver, options);
    if (observer.current && !isFetching) {
      observer.current.observe(document.getElementById('lazy-load-trigger'));
    }

    return () => {
      if (observer.current) {
        observer.current.disconnect();
      }
    };
  }, [isFetching]);

  useEffect(() => {
    if (!isFetching) return;
    const fetchMorePokemonData = async () => {
      const response = await axios.get(
        `https://pokeapi.co/api/v2/pokemon?offset=${currentPage * pokemonPerPage}&limit=${pokemonPerPage}`
      );
      setPokemonData(prevData => [...prevData, ...response.data.results]);
      setIsFetching(false);
    };

    fetchMorePokemonData();
  }, [isFetching, currentPage]);

  const handleSearchChange = e => {
    setSearchTerm(e.target.value);
  };

  const handlePageChange = pageNumber => {
    setCurrentPage(pageNumber);
  };

  const indexOfLastPokemon = currentPage * pokemonPerPage;
  const indexOfFirstPokemon = indexOfLastPokemon - pokemonPerPage;
  const currentPokemon = filteredPokemonData.slice(indexOfFirstPokemon, indexOfLastPokemon);

  return (
    <div>
      <h1>Pokémon List - Lazy Load</h1>
      <input type="text" placeholder="Search Pokémon" value={searchTerm} onChange={handleSearchChange} />
      <ul>
        {currentPokemon.map(pokemon => (
          <li key={pokemon.name}>{pokemon.name}</li>
        ))}
      </ul>
      <div id="lazy-load-trigger" style={{ visibility: 'hidden' }}></div>
      {isFetching && <p>Loading more Pokémon...</p>}
      <div>
        {filteredPokemonData.length > pokemonPerPage && (
          <ul className="pagination">
            {Array(Math.ceil(filteredPokemonData.length / pokemonPerPage))
              .fill()
              .map((_, index) => (
                <li key={index + 1} className={currentPage === index + 1 ? 'active' : ''}>
                  <button onClick={() => handlePageChange(index + 1)}>{index + 1}</button>
                </li>
              ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default LazyLoadPokemonList;
